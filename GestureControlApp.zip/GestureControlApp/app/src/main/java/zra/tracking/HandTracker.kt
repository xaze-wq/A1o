package zra.tracking

import android.content.Context
import android.graphics.Bitmap
import androidx.camera.core.ImageProxy
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker.HandLandmarkerOptions
import com.google.mediapipe.framework.image.BitmapImageBuilder
import zra.utils.toBitmap

class HandTracker(
    private val context: Context,
    private val gestureListener: (List<com.google.mediapipe.framework.formats.proto.LandmarkProto.NormalizedLandmark>, Bitmap) -> Unit
) {
    private val hands by lazy {
        HandLandmarker.createFromOptions(
            context,
            HandLandmarkerOptions.builder()
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setMinHandDetectionConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setResultListener(this::handleResult)
                .build()
        )
    }

    fun analyzeFrame(image: ImageProxy) {
        val bitmap = image.toBitmap()
        val mpImage = BitmapImageBuilder(bitmap).build()
        hands.detectAsync(mpImage, image.imageInfo.timestamp)
        image.close()
    }

    private fun handleResult(result: HandLandmarkerResult, input: ImageProxy) {
        val landmarks = result.landmarks().firstOrNull()
        val bitmap = input.toBitmap()
        if (landmarks != null && bitmap != null) {
            gestureListener(landmarks, bitmap)
        }
    }
}