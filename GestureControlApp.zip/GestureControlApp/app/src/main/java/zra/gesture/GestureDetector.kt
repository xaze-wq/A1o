package zra.gesture

import kotlin.math.abs
import com.google.mediapipe.framework.formats.proto.LandmarkProto.NormalizedLandmark

sealed class Gesture {
    object Click : Gesture()
    object DoubleClick : Gesture()
    object ZoomIn : Gesture()
    object ZoomOut : Gesture()
    object ScrollUp : Gesture()
    object ScrollDown : Gesture()
    object ScrollLeft : Gesture()
    object ScrollRight : Gesture()
    object Back : Gesture()
    object Exit : Gesture()
    object None : Gesture()
}

class GestureDetector {
    companion object {
        const val CLICK_DISTANCE_THRESHOLD = 0.05f
        const val DOUBLE_CLICK_TIME_THRESHOLD = 500L
    }

    private var lastClickTime = 0L
    private var lastFistTime = 0L
    private var previousDistance = 0f

    fun detect(landmarks: List<NormalizedLandmark>): Gesture {
        val indexTip = landmarks[8]
        val thumbTip = landmarks[4]
        val palmCenter = landmarks[0]

        val clickDistance = calculateDistance(indexTip, thumbTip)
        if (clickDistance < CLICK_DISTANCE_THRESHOLD) {
            val currentTime = System.currentTimeMillis()
            if (currentTime - lastClickTime < DOUBLE_CLICK_TIME_THRESHOLD) {
                lastClickTime = 0
                return Gesture.DoubleClick
            }
            lastClickTime = currentTime
            return Gesture.Click
        }

        val currentDistance = calculateDistance(indexTip, thumbTip)
        val distanceChange = currentDistance - previousDistance
        previousDistance = currentDistance
        if (abs(distanceChange) > 0.1f) {
            return if (distanceChange > 0) Gesture.ZoomOut else Gesture.ZoomIn
        }

        val movementX = indexTip.x - palmCenter.x
        val movementY = indexTip.y - palmCenter.y
        if (movementX > 0.1f) return Gesture.ScrollRight
        if (movementX < -0.1f) return Gesture.ScrollLeft
        if (movementY > 0.1f) return Gesture.ScrollDown
        if (movementY < -0.1f) return Gesture.ScrollUp

        if (isFist(landmarks)) {
            val currentTime = System.currentTimeMillis()
            if (currentTime - lastFistTime < DOUBLE_CLICK_TIME_THRESHOLD) {
                return Gesture.Exit
            }
            lastFistTime = currentTime
            return Gesture.Back
        }

        return Gesture.None
    }

    private fun calculateDistance(p1: NormalizedLandmark, p2: NormalizedLandmark): Float {
        return kotlin.math.sqrt(
            (p1.x - p2.x) * (p1.x - p2.x) +
            (p1.y - p2.y) * (p1.y - p2.y)
        )
    }

    private fun isFist(landmarks: List<NormalizedLandmark>): Boolean {
        val palm = landmarks[0]
        return listOf(8, 12, 16, 20).all { fingerTipIndex ->
            calculateDistance(palm, landmarks[fingerTipIndex]) < 0.1f
        }
    }
}