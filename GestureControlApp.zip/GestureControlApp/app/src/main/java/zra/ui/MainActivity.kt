package zra.ui

import android.graphics.Point
import android.os.Bundle
import android.os.SystemClock
import android.view.MotionEvent
import androidx.appcompat.app.AppCompatActivity
import zra.camera.CameraManager
import zra.cursor.CursorService
import zra.gesture.Gesture
import zra.gesture.GestureDetector
import zra.tracking.HandTracker

class MainActivity : AppCompatActivity() {
    private lateinit var cameraManager: CameraManager
    private lateinit var handTracker: HandTracker
    private lateinit var gestureDetector: GestureDetector
    private lateinit var cursorService: CursorService

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cursorService = CursorService(this)
        gestureDetector = GestureDetector()
        cameraManager = CameraManager(this, findViewById(R.id.preview_view))

        handTracker = HandTracker(this) { landmarks, bitmap ->
            val gesture = gestureDetector.detect(landmarks)
            val indexTip = landmarks[8]
            val screenPoint = convertToScreenCoordinates(indexTip, bitmap.width, bitmap.height)
            cursorService.updatePosition(screenPoint.x, screenPoint.y)

            when (gesture) {
                Gesture.Click -> {
                    cursorService.performClickAnimation()
                    simulateClick(screenPoint)
                }
                Gesture.ZoomIn -> performZoom(1.25f)
                Gesture.Back -> onBackPressed()
                else -> {}
            }
        }

        if (checkPermissions()) {
            cameraManager.startCamera(handTracker::analyzeFrame)
        }
    }

    private fun convertToScreenCoordinates(landmark: NormalizedLandmark, width: Int, height: Int): Point {
        return Point((landmark.x * width).toInt(), (landmark.y * height).toInt())
    }

    private fun simulateClick(point: Point) {
        val eventTime = SystemClock.uptimeMillis()
        val downEvent = MotionEvent.obtain(eventTime, eventTime, MotionEvent.ACTION_DOWN, point.x.toFloat(), point.y.toFloat(), 0)
        val upEvent = MotionEvent.obtain(eventTime, eventTime, MotionEvent.ACTION_UP, point.x.toFloat(), point.y.toFloat(), 0)
        window.decorView.dispatchTouchEvent(downEvent)
        window.decorView.dispatchTouchEvent(upEvent)
    }
}